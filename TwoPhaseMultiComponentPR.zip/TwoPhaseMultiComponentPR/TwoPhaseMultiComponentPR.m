clear;close all;clc;
delete 'output/*.mat';
delete '*.asv';
pr_mc_cn();
figure
load(['output/','global.mat'],'x_inner','y_inner');
pathname = 'output/';
filename = 'data10';
load([pathname,filename],'ph1');
subplot(3,1,1);
pcolor(x_inner,y_inner,ph1);
colormap jet
colorbar;
axis equal;
shading interp;
set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 0 1.0])
box on
title('$t=0.01$','Interpreter','latex');
filename = 'data500';
load([pathname,filename],'ph1');
subplot(3,1,2);
pcolor(x_inner,y_inner,ph1);
colorbar;
axis equal;
shading interp;
set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 0 1.0])
box on
title('$t=0.50$','Interpreter','latex');
filename = 'data1000';
load([pathname,filename],'ph1');
subplot(3,1,3);
pcolor(x_inner,y_inner,ph1);
colorbar;
axis equal;
shading interp;
set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 0 1.0])
box on
title('$t=1.00$','Interpreter','latex');
figure
load(['output/','global.mat'],'x_inner','y_inner');
pathname = 'output/';
filename = 'data10';
load([pathname,filename],'ph2');
subplot(3,1,1);
pcolor(x_inner,y_inner,ph2);
colormap jet
colorbar;
axis equal;
shading interp;
set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 0 1.0])
box on
title('$t=0.01$','Interpreter','latex');
filename = 'data500';
load([pathname,filename],'ph2');
subplot(3,1,2);
pcolor(x_inner,y_inner,ph2);
colorbar;
axis equal;
shading interp;
set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 0 1.0])
box on
title('$t=0.50$','Interpreter','latex');
filename = 'data1000';
load([pathname,filename],'ph2');
subplot(3,1,3);
pcolor(x_inner,y_inner,ph2);
colorbar;
axis equal;
shading interp;
set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 0 1.0])
box on
title('$t=1.00$','Interpreter','latex');
figure
load(['output/','global.mat'],'x_inner','y_inner');
pathname = 'output/';
filename = 'data10';
load([pathname,filename],'ph3');
subplot(3,1,1);
pcolor(x_inner,y_inner,ph3);
colormap jet
colorbar;
axis equal;
shading interp;
set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 0 1.0])
box on
title('$t=0.01$','Interpreter','latex');
filename = 'data500';
load([pathname,filename],'ph3');
subplot(3,1,2);
pcolor(x_inner,y_inner,ph3);
colorbar;
axis equal;
shading interp;
set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 0 1.0])
box on
title('$t=0.50$','Interpreter','latex');
filename = 'data1000';
load([pathname,filename],'ph3');
subplot(3,1,3);
pcolor(x_inner,y_inner,ph3);
colorbar;
axis equal;
shading interp;
set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 0 1.0])
box on
title('$t=1.00$','Interpreter','latex');
pathname = 'output/';
lgm1_vec = zeros(1000+1,1);
lgm2_vec = zeros(1000+1,1);
lgm3_vec = zeros(1000+1,1);
t_vec = zeros(1000+1,1);
    for i = 0:1:1000
        filename = ['data' int2str(i)];
        load([pathname,filename],'lgm1','lgm2','lgm3','t');
        lgm1_vec(i+1) = lgm1;
        lgm2_vec(i+1) = lgm2;
        lgm3_vec(i+1) = lgm3;
        t_vec(i+1) = t;
    end
figure
subplot(3,1,1);
    scatter(t_vec,lgm1_vec,'red','filled');
    % xlabel('$t$','Interpreter','latex','Fontsize',16)
    % ylabel('$r^{\frac{1}{M}}$','Interpreter','latex','Fontsize',16)
    % set(gca,'FontName','Times New Roman','FontSize',7,'LineWidth',1.5);
% axis equal;
% shading interp;
% set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 1-1.0e-9 1+1.0e-9])
box on
title('$r^{k+\frac{1}{M}}$','Interpreter','latex','FontSize',20);
subplot(3,1,2);
    scatter(t_vec,lgm2_vec,'green','filled');
    % xlabel('$t$','Interpreter','latex','Fontsize',16)
    % ylabel('$r^{\frac{2}{M}}$','Interpreter','latex','Fontsize',16)
% axis equal;
% shading interp;
% set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 1-1.0e-9 1+1.0e-9])
box on
title('$r^{k+\frac{2}{M}}$','Interpreter','latex','FontSize',20);
subplot(3,1,3);
    scatter(t_vec,lgm3_vec,'blue','filled');
    % xlabel('$t$','Interpreter','latex','Fontsize',16)
    % ylabel('$r^{\frac{3}{M}}$','Interpreter','latex','Fontsize',16)
% axis equal;
% shading interp;
% set(gca,'xticklabel',[],'yticklabel',[])
axis([0 1.0 1-1.0e-9 1+1.0e-9])
box on
title('$r^{k+\frac{3}{M}}$','Interpreter','latex','FontSize',20);
function [ph1,mu1,ph2,mu2,ph3,mu3,u,v] = initial_condition()
    load(['output/','global.mat'],'nx','ny','dx','dy','thickness1','thickness2','thickness3','binary_thickness', ...
        'H_para','Theta','n_c','lambda1','lambda2','lambda3','psi1','psi2','psi3','binary', ...
        'tension1','tension2','tension3','angle_B','angle_T','Bol','eta','uwB','uwT','beta_uw');
    ph1_gas = 7.1339;
    ph1_liquid = 3.5132;
    ph1 = ph1_gas*ones(ny+2,nx+2);
    ph1(4*(ny-1)/10+2:6*(ny-1)/10+2,4*(nx-1)/10+2:6*(nx-1)/10+2) = ph1_liquid;
    ph1 = boundary_condition(ph1,'0NM','RBC');
    ph1(1,2:nx+1) = ph1(4,2:nx+1) - 3*ph1(3,2:nx+1) + 3*ph1(2,2:nx+1);
    ph1(ny+2,2:nx+1) = ph1(ny-1,2:nx+1) - 3*ph1(ny,2:nx+1) + 3*ph1(ny+1,2:nx+1);
    ph2_gas = 0.77;
    ph2_liquid = 1.9925;
    ph2 = ph2_gas*ones(ny+2,nx+2);
    ph2(4*(ny-1)/10+2:6*(ny-1)/10+2,4*(nx-1)/10+2:6*(nx-1)/10+2) = ph2_liquid;
    ph2 = boundary_condition(ph2,'0NM','RBC');
    ph2(1,2:nx+1) = ph2(4,2:nx+1) - 3*ph2(3,2:nx+1) + 3*ph2(2,2:nx+1);
    ph2(ny+2,2:nx+1) = ph2(ny-1,2:nx+1) - 3*ph2(ny,2:nx+1) + 3*ph2(ny+1,2:nx+1);
    ph3_gas = 0.184;
    ph3_liquid = 1.433;
    ph3 = ph3_gas*ones(ny+2,nx+2);
    ph3(4*(ny-1)/10+2:6*(ny-1)/10+2,4*(nx-1)/10+2:6*(nx-1)/10+2) = ph3_liquid;
    ph3 = boundary_condition(ph3,'0NM','RBC');
    ph3(1,2:nx+1) = ph3(4,2:nx+1) - 3*ph3(3,2:nx+1) + 3*ph3(2,2:nx+1);
    ph3(ny+2,2:nx+1) = ph3(ny-1,2:nx+1) - 3*ph3(ny,2:nx+1) + 3*ph3(ny+1,2:nx+1);
    ph_sum1 = ph1 + ph2 + ph3;
    ph_sum2 = lambda1*ph1 + lambda2*ph2 + lambda3*ph3;
    ph_sum3 = psi1*ph1.*ph1 + psi2*ph2.*ph2 + psi3*ph3.*ph3 ...
        + 2*(1-binary)*sqrt(psi1*psi2)*ph1.*ph2 + 2*(1-binary)*sqrt(psi1*psi3)*ph1.*ph3 + 2*(1-binary)*sqrt(psi2*psi3)*ph2.*ph3;
    mu10_ideal = Theta*(log(ph1) + log(n_c))/H_para;
    mu10_repulsion = Theta*(lambda1*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2/H_para))/H_para;
    mu10_attraction = (2*(psi1*ph1 + (1-binary)*sqrt(psi1*psi2)*ph2 + (1-binary)*sqrt(psi1*psi3)*ph3)./(H_para*ph_sum2) ...
        - lambda1*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
        + lambda1*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) ); 
    mu10 = mu10_ideal + mu10_repulsion + mu10_attraction;
    mu1 = zeros(ny+2,nx+2);
    mu1(2:ny+1,2:nx+1) = mu10(2:ny+1,2:nx+1) - thickness1^2*diff2xy(ph1) - binary_thickness^2*diff2xy(ph2) - binary_thickness^2*diff2xy(ph3);
    mu1 = boundary_condition(mu1,'0NM','0NM');
    mu20_ideal = Theta*(log(ph2) + log(n_c))/H_para;
    mu20_repulsion = Theta*(lambda2*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2/H_para))/H_para;
    mu20_attraction = (2*((1-binary)*sqrt(psi1*psi2)*ph1 + psi2*ph2 + (1-binary)*sqrt(psi2*psi3)*ph3)./(H_para*ph_sum2) ...
        - lambda2*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
        + lambda2*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) ); 
    mu20 = mu20_ideal + mu20_repulsion + mu20_attraction;
    mu2 = zeros(ny+2,nx+2);
    mu2(2:ny+1,2:nx+1) = mu20(2:ny+1,2:nx+1) - thickness2^2*diff2xy(ph2) - binary_thickness^2*diff2xy(ph1) - binary_thickness^2*diff2xy(ph3);
    mu2 = boundary_condition(mu2,'0NM','0NM');
    mu30_ideal = Theta*(log(ph3) + log(n_c))/H_para;
    mu30_repulsion = Theta*(lambda3*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2/H_para))/H_para;
    mu30_attraction = (2*((1-binary)*sqrt(psi1*psi3)*ph1 + (1-binary)*sqrt(psi2*psi3)*ph2 + psi3*ph3)./(H_para*ph_sum2) ...
        - lambda3*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
        + lambda3*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) ); 
    mu30 = mu30_ideal + mu30_repulsion + mu30_attraction;
    mu3 = zeros(ny+2,nx+2);
    mu3(2:ny+1,2:nx+1) = mu30(2:ny+1,2:nx+1) - thickness3^2*diff2xy(ph3) - binary_thickness^2*diff2xy(ph1) - binary_thickness^2*diff2xy(ph2);
    mu3 = boundary_condition(mu3,'0NM','0NM');
    cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
    L1_B = cf_B*tension1*cos(pi*(ph1(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness1*(ph1(1,2:nx+1)-ph1(3,2:nx+1))/(2*dy) + binary_thickness*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy) + binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy);
    cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
    L1_T = cf_T*tension1*cos(pi*(ph1(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness1*(ph1(ny+2,2:nx+1)-ph1(ny,2:nx+1))/(2*dy) + binary_thickness*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy) + binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy);
    L2_B = cf_B*tension2*cos(pi*(ph2(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness2*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy) + binary_thickness*(ph1(1,2:nx+1)-ph1(3,2:nx+1))/(2*dy) + binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy);
    L2_T = cf_T*tension2*cos(pi*(ph2(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness2*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy) + binary_thickness*(ph1(ny+2,2:nx+1)-ph1(ny,2:nx+1))/(2*dy) + binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy);
    L3_B = cf_B*tension3*cos(pi*(ph3(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness3*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy) + binary_thickness*(ph1(1,2:nx+1)-ph1(3,2:nx+1))/(2*dy) + binary_thickness*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy);
    L3_T = cf_T*tension3*cos(pi*(ph3(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness3*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy) + binary_thickness*(ph1(ny+2,2:nx+1)-ph1(ny,2:nx+1))/(2*dy) + binary_thickness*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy);
    u  = zeros(ny+2,nx+2);
    u = boundary_condition(u,'0NM','GNBC');
    u(1,2:nx+1) = 2*dy*( Bol*( L1_B.*(ph1(2,3:nx+2)-ph1(2,1:nx))/(2*dx) + L2_B.*(ph2(2,3:nx+2)-ph2(2,1:nx))/(2*dx) + L3_B.*(ph3(2,3:nx+2)-ph3(2,1:nx))/(2*dx) )/eta ...
            - beta_uw*(u(2,2:nx+1)-uwB) ) + u(3,2:nx+1);
    u(ny+2,2:nx+1) = 2*dy*( Bol*( L1_T.*(ph1(ny+1,3:nx+2)-ph1(ny+1,1:nx))/(2*dx) + L2_T.*(ph2(ny+1,3:nx+2)-ph2(ny+1,1:nx))/(2*dx) + L3_T.*(ph3(ny+1,3:nx+2)-ph3(ny+1,1:nx))/(2*dx) )/eta ...
            - beta_uw*(u(ny+1,2:nx+1)-uwT) ) + u(ny,2:nx+1);
    v  = zeros(ny+2,nx+2);
    v = boundary_condition(v,'0NM','0DBC');
    F_bcd = 0.0;
    save(['output/','F_bcd.mat'],'F_bcd');
end
function [data_count,dissip2] = save_output(i,data_count,t,dissip1,ph1,mu1,ph2,mu2,ph3,mu3,lgm1,lgm2,lgm3,u,v)
    load(['output/','global.mat'],'ny','nx','data_step');
    if floor(i/data_step)*data_step == i
        [dissip2,Ft]= dissipation(ph1,mu1,ph2,mu2,ph3,mu3,u,v);
        if i ~= 0
            % fprintf('(dissip2-dissip1)/dissip1 = %s. ',(dissip2-dissip1)/dissip1);
            % if abs(dissip2-dissip1)/dissip2 <= 1.0e-3 
            %     fprintf('stable by dissipation.');
            % end
        end
        pathname = 'output/';
        filename = ['data' int2str(data_count) '.mat'];
        ph1 = ph1(2:ny+1,2:nx+1);
        ph2 = ph2(2:ny+1,2:nx+1);
        ph3 = ph3(2:ny+1,2:nx+1);
        u = u(2:ny+1,2:nx+1);
        v = v(2:ny+1,2:nx+1);
        save([pathname,filename],'ph1','ph2','ph3','lgm1','lgm2','lgm3','Ft','u','v','t');
        % fprintf('step = %d, ',i);
        % fprintf('t = %f, ',t);
        % fprintf(['data saved in ' filename '\n']);
        if data_count > 4999
            fprintf('no engouh data files to save');
            stop;
        end
        data_count = data_count + 1; 
    else
        dissip2 = dissip1;
    end
end
function [dissip, Ft] = dissipation(ph1,mu1,ph2,mu2,ph3,mu3,u,v)
    load(['output/','global.mat'],'nx','ny','dx','dy','dt','weight','thickness1','thickness2','thickness3','binary_thickness','Re', ...
        'mobility1','mobility2','mobility3','H_para','Theta','n_c','lambda1','lambda2','lambda3','psi1','psi2','psi3','ph1_weight','ph2_weight','ph3_weight', ...
        'tension1','tension2','tension3','vs1','vs2','vs3','angle_B','angle_T','binary','Bol','xi','eta','beta_uw','uwB','uwT');
    e1 = Bol*mobility1*sum(weight.*(diff1x(mu1).^2 + diff1y(mu1).^2),'all')*dx*dy;
    e1 = e1 + Bol*mobility2*sum(weight.*(diff1x(mu2).^2 + diff1y(mu2).^2),'all')*dx*dy;
    e1 = e1 + Bol*mobility3*sum(weight.*(diff1x(mu3).^2 + diff1y(mu3).^2),'all')*dx*dy;
    cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
    e2_1_B = cf_B*tension1*cos(pi*(ph1(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness1*(ph1(1,2:nx+1)-ph1(3,2:nx+1))/(2*dy) + binary_thickness*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy) + binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy);
    cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
    e2_1_T = cf_T*tension1*cos(pi*(ph1(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness1*(ph1(ny+2,2:nx+1)-ph1(ny,2:nx+1))/(2*dy) + binary_thickness*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy) + binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy);
    e2_2_B = cf_B*tension2*cos(pi*(ph2(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness2*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy) + binary_thickness*(ph1(1,2:nx+1)-ph1(3,2:nx+1))/(2*dy) + binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy);
    e2_2_T = cf_T*tension2*cos(pi*(ph2(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness2*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy) + binary_thickness*(ph1(ny+2,2:nx+1)-ph1(ny,2:nx+1))/(2*dy) + binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy);
    e2_3_B = cf_B*tension3*cos(pi*(ph3(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness3*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy) + binary_thickness*(ph1(1,2:nx+1)-ph1(3,2:nx+1))/(2*dy) + binary_thickness*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy);
    e2_3_T = cf_T*tension3*cos(pi*(ph3(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness3*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy) + binary_thickness*(ph1(ny+2,2:nx+1)-ph1(ny,2:nx+1))/(2*dy) + binary_thickness*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy);
    e2 = sum(weight(1,:).*e2_1_B,'all')*vs1*Bol*dx + sum(weight(ny,:).*e2_1_T,'all')*vs1*Bol*dx;
    e2 = e2 + sum(weight(1,:).*e2_2_B,'all')*vs2*Bol*dx + sum(weight(ny,:).*e2_2_T,'all')*vs2*Bol*dx;
    e2 = e2 + sum(weight(1,:).*e2_3_B,'all')*vs3*Bol*dx + sum(weight(ny,:).*e2_3_T,'all')*vs3*Bol*dx;
    div_v = (u(2:ny+1,3:nx+2)-u(2:ny+1,1:nx))/(2*dx) + (v(3:ny+2,2:nx+1)-v(1:ny,2:nx+1))/(2*dy);
    e3 = (xi-2*eta/3)*sum(weight.*(div_v.^2),'all')*dx*dy;
    Dv = 2*( (u(2:ny+1,3:nx+2)-u(2:ny+1,1:nx))/(2*dx) ).^2 + 2*( (v(3:ny+2,2:nx+1)-v(1:ny,2:nx+1))/(2*dy) ).^2 ...
        +( (u(3:ny+2,2:nx+1)-u(1:ny,2:nx+1))/(2*dy) ).^2 + ( (v(2:ny+1,3:nx+2)-v(2:ny+1,1:nx))/(2*dx) ).^2;
    e4 = 0.5*eta*sum(weight.*Dv,'all')*dx*dy;
    cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
    L1_B = cf_B*tension1*cos(pi*(ph1(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness1*(ph1(1,2:nx+1)-ph1(3,2:nx+1))/(2*dy) + binary_thickness*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy) + binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy);
    cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
    L1_T = cf_T*tension1*cos(pi*(ph1(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness1*(ph1(ny+2,2:nx+1)-ph1(ny,2:nx+1))/(2*dy) + binary_thickness*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy) + binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy);
    L2_B = cf_B*tension2*cos(pi*(ph2(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness2*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy) + binary_thickness*(ph1(1,2:nx+1)-ph1(3,2:nx+1))/(2*dy) + binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy);
    L2_T = cf_T*tension2*cos(pi*(ph2(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness2*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy) + binary_thickness*(ph1(ny+2,2:nx+1)-ph1(ny,2:nx+1))/(2*dy) + binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy);
    L3_B = cf_B*tension3*cos(pi*(ph3(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness3*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy) + binary_thickness*(ph1(1,2:nx+1)-ph1(3,2:nx+1))/(2*dy) + binary_thickness*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy);
    L3_T = cf_T*tension3*cos(pi*(ph3(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness3*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy) + binary_thickness*(ph1(ny+2,2:nx+1)-ph1(ny,2:nx+1))/(2*dy) + binary_thickness*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy);
    u_star_slip_B = Bol*( L1_B.*(ph1(2,3:nx+2)-ph1(2,1:nx))/(2*dx) + L2_B.*(ph2(2,3:nx+2)-ph2(2,1:nx))/(2*dx) + L3_B.*(ph3(2,3:nx+2)-ph3(2,1:nx))/(2*dx) )/(eta*beta_uw);
    u_star_slip_T = Bol*( L1_T.*(ph1(ny+1,3:nx+2)-ph1(ny+1,1:nx))/(2*dx) + L2_T.*(ph2(ny+1,3:nx+2)-ph2(ny+1,1:nx))/(2*dx) + L3_T.*(ph3(ny+1,3:nx+2)-ph3(ny+1,1:nx))/(2*dx) )/(eta*beta_uw);
    u_slip_B = u(2,2:nx+1) - uwB;
    u_slip_T = u(ny+1,2:nx+1)-uwT;
    e5_B = u_slip_B.^2 + u_star_slip_B.^2 + (u_slip_B - u_star_slip_B).^2;
    e5_T = u_slip_T.^2 + u_star_slip_T.^2 + (u_slip_T - u_star_slip_T).^2;
    e5 = sum(weight(1,:).*e5_B,'all')*0.5*beta_uw*eta*dx + sum(weight(ny,:).*e5_T,'all')*0.5*beta_uw*eta*dx;
    dissip = e1 + e2 + e3 + e4 + e5;
    ph_sum1 = ph1 + ph2 + ph3;
    ph_sum2 = lambda1*ph1 + lambda2*ph2 + lambda3*ph3;
    ph_sum3 = psi1*ph1.*ph1 + psi2*ph2.*ph2 + psi3*ph3.*ph3 ...
        + 2*(1-binary)*sqrt(psi1*psi2)*ph1.*ph2 + 2*(1-binary)*sqrt(psi1*psi3)*ph1.*ph3 + 2*(1-binary)*sqrt(psi2*psi3)*ph2.*ph3;
    f1_ideal = Theta*(ph1.*(log(ph1) + log(n_c) - 1) + ph2.*(log(ph2) + log(n_c) - 1) + ph3.*(log(ph3) + log(n_c) - 1))/H_para;
    f1_repulsion = -Theta*(ph_sum1.*log(1-ph_sum2/H_para))/H_para;
    f1_attraction = ph_sum3.*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))./(2*sqrt(2)*H_para*ph_sum2);
    f1 = f1_ideal(2:ny+1,2:nx+1) + f1_repulsion(2:ny+1,2:nx+1) + f1_attraction(2:ny+1,2:nx+1);
    f1 = f1 + 0.5*thickness1^2*(diff1x(ph1).^2 + diff1y(ph1).^2) + 0.5*thickness2^2*(diff1x(ph2).^2 + diff1y(ph2).^2) + 0.5*thickness3^2*(diff1x(ph3).^2 + diff1y(ph3).^2) ...
        + binary_thickness^2*(diff1x(ph1).*diff1x(ph2) + diff1y(ph1).*diff1y(ph2)) + binary_thickness^2*(diff1x(ph1).*diff1x(ph3) + diff1y(ph1).*diff1y(ph3)) + binary_thickness^2*(diff1x(ph2).*diff1x(ph3) + diff1y(ph2).*diff1y(ph3));
    F1 = sum(weight.*f1,'all')*Bol*dx*dy;
    cf_B = -Theta*cos(angle_B*pi/180)/(6*sqrt(2)*H_para);
    f2_B = cf_B*(tension1*sin(pi*(ph1(2,2:nx+1) - 1)/2 + pi/4) + tension2*sin(pi*(ph2(2,2:nx+1) - 1)/2 + pi/4) + tension3*sin(pi*(ph3(2,2:nx+1) - 1)/2 + pi/4));
    cf_T = -Theta*cos(angle_T*pi/180)/(6*sqrt(2)*H_para);
    f2_T = cf_T*(tension1*sin(pi*(ph1(ny+1,2:nx+1) - 1)/2 + pi/4) + tension2*sin(pi*(ph2(ny+1,2:nx+1) - 1)/2 + pi/4) + tension3*sin(pi*(ph3(ny+1,2:nx+1) - 1)/2 + pi/4));
    F2 = sum(weight(1,:).*f2_B,'all')*Bol*dx + sum(weight(ny,:).*f2_T,'all')*Bol*dx;
    rho = ph1_weight*ph1(2:ny+1,2:nx+1) + ph2_weight*ph2(2:ny+1,2:nx+1) + ph3_weight*ph3(2:ny+1,2:nx+1);
    f3 = 0.5*rho.*( u(2:ny+1,2:nx+1).^2 + v(2:ny+1,2:nx+1).^2 );
    F3 = sum(weight.*f3,'all')*Re*dx*dy;
    load(['output/','F_bcd.mat'],'F_bcd');
    F_bcd = F_bcd + sum(weight(1,:).*u_slip_B*uwB*0.5,'all')*dt*dx*eta*beta_uw + sum(weight(ny,:).*u_slip_T*uwT*0.5,'all')*dt*dx*eta*beta_uw;
    save(['output/','F_bcd.mat'],'F_bcd');
    Ft = F1 + F2 + F3 + F_bcd;
end 
% function u = redistribution(u,lower_bound,upper_bound)
%     load(['output/','global.mat'],'ny','nx','weight');
%     Sg_count = 0;
%     Sg1 = sum(weight.*u(2:ny+1,2:nx+1),'all');
%     tol = 1.0e-7;
%     for i = 2:ny+1
%         for j = 2:nx+1
%             if u(i,j) > upper_bound + tol
%                 u(i, j) = upper_bound;
%             elseif u(i,j) < lower_bound - tol
%                 u(i,j) = lower_bound;
%             else
%                 Sg_count = Sg_count + weight(i-1, j-1);
%             end
%         end
%     end
%     Sg2 = sum(weight.*u(2:ny+1,2:nx+1),'all');
%     Sg1 = (Sg1 - Sg2) / Sg_count;
%     for i = 2:ny+1
%         for j = 2:nx+1
%             if lower_bound < u(i,j) && u(i,j) < upper_bound
%                 u(i,j) = u(i, j) + Sg1;
%             end
%             if u(i,j) > upper_bound + tol || u(i,j) < lower_bound - tol
%                 fprintf('ph = %.10f\n',u(i,j));
%                 error('ph exceed')
%             end
%         end
%     end
% end
function u = boundary_condition(u,lr,bt)
    [M,N] = size(u);
    if strcmp(lr,'0NM') == 1
        u(2:M-1,1) = u(2:M-1,3);
        u(2:M-1,N) = u(2:M-1,N-2);
    elseif strcmp(lr,'PBC') == 1
        u(2:M-1,1) = u(2:M-1,N-2);
        u(2:M-1,N-1) = u(2:M-1,2);
        u(2:M-1,N) = u(2:M-1,3);
    else
        fprintf('wrong input in left and right boundary condition');
        quit;
    end
    if strcmp(bt,'0NM') == 1
        u(1,2:N-1) = u(3,2:N-1);
        u(M,2:N-1) = u(M-2,2:N-1);
    elseif strcmp(bt,'PBC') == 1
        u(1,2:N-1) = u(M-2,2:N-1);
        u(M-1,2:N-1) = u(2,2:N-1);
        u(M,2:N-1) = u(3,2:N-1);
    elseif strcmp(bt,'0DBC') == 1
        u(2,2:N-1) = 0;
        u(1,2:N-1) = -u(3,2:N-1);
        u(M-1,2:N-1) = 0;
        u(M,2:N-1) = -u(M-2,2:N-1);
    elseif strcmp(bt,'RBC') == 1
        return
    elseif strcmp(bt,'GNBC') == 1
        return
    else
        fprintf('wrong input in bottom and top boundary condition');
        quit;
    end
end
function du = diff1x(u)
    load(['output/','global.mat'],'dx');
    [M,N] = size(u);
    [du,~] = gradient(u);
    du = du(2:M-1,2:N-1)/dx;
end
function du = diff1y(u)
    load(['output/','global.mat'],'dy');
    [M,N] = size(u);
    [~,du] = gradient(u);
    du = du(2:M-1,2:N-1)/dy;
end
function du = diff1xy(u)
    load(['output/','global.mat'],'dx','dy');
    [M,N] = size(u);
    [dux,~] = gradient(u);
    dux = dux(:,2:N-1)/dx;
    [~,du] = gradient(dux);
    du = du(2:M-1,:)/dy;
end
function du = diff2x(u)
    load(['output/','global.mat'],'dx');
    [M,~] = size(u);
    du = diff(u,2,2);
    du = du(2:M-1,:)/dx^2;
end
function du = diff2y(u)
    load(['output/','global.mat'],'dy');
    [~,N] = size(u);
    du = diff(u,2,1);
    du = du(:,2:N-1)/dy^2;
end
function du = diff2xy(u)
    load(['output/','global.mat'],'dx','dy');
    [M,N] = size(u);
    dux = diff(u,2,2);
    duy = diff(u,2,1);
    du = dux(2:M-1,:)/dx^2+duy(:,2:N-1)/dy^2;
end
function pr_mc_cn()
    global_variable();
    load(['output/','global.mat'],'nt','dt','t_final');
    data_count = 0;
    t = 0;
    [ph1,mu1,ph2,mu2,ph3,mu3,u,v] = initial_condition();
    lgm1 = 1.0; lgm2 = 1.0; lgm3 = 1.0;
    [data_count,dissip] = save_output(0,data_count,t,0,ph1,mu1,ph2,mu2,ph3,mu3,lgm1,lgm2,lgm3,u,v);
    for i = 1:nt
        t = t + dt;
        [ph1_new,mu1_new,ph2_new,mu2_new,ph3_new,mu3_new,lgm1_new,lgm2_new,lgm3_new] = ph_solve(i,ph1,ph2,ph3,u,v);
        [u_new,v_new] = vel_solve(u,v,ph1_new,ph2_new,ph3_new);
        ph1 = ph1_new;
        mu1 = mu1_new;
        ph2 = ph2_new;
        mu2 = mu2_new;
        ph3 = ph3_new;
        mu3 = mu3_new;
        lgm1 = lgm1_new;
        lgm2 = lgm2_new;
        lgm3 = lgm3_new;
        u = u_new;
        v = v_new;
        [data_count,dissip] = save_output(i,data_count,t,dissip,ph1,mu1,ph2,mu2,ph3,mu3,lgm1,lgm2,lgm3,u,v);
    end 
    fprintf('\n');
    fprintf('t_final = %.4f \n',t_final);
end
function [ph1_new,mu1_new,ph2_new,mu2_new,ph3_new,mu3_new,lgm1_new,lgm2_new,lgm3_new] = ph_solve(i,ph1,ph2,ph3,u,v)
    load(['output/','global.mat'],'nx','ny','dx','dy','dt','thickness1','thickness2','thickness3','binary_thickness','tension1','tension2','tension3', ...
        'mobility1','mobility2','mobility3','vs1','vs2','vs3','H_para','Theta','n_c','lambda1','lambda2','lambda3','psi1','psi2','psi3',...
        'angle_B','angle_T','binary','Bol','Ka','Re','ph1_weight','ph2_weight','ph3_weight','beta_uw','eta','uwB','uwT');
    alpha1 = 9.0;
    alpha2 = 1/dt/alpha1;
    beta1 = -(alpha1*mobility1 + thickness1^2*alpha2);
    beta2 = -(alpha1*mobility2 + thickness2^2*alpha2);
    beta3 = -(alpha1*mobility3 + thickness3^2*alpha2);
    if i == 1
        u1_ph1_old = ph1;
        u2_ph1_old = ph1;
        u1_ph2_old = ph2;
        u2_ph2_old = ph2;
        u1_ph3_old = ph3;
        u2_ph3_old = ph3;
    else
        load(['output/','u1_ph1.mat'],'u1_ph1_old');
        load(['output/','u2_ph1.mat'],'u2_ph1_old');
        load(['output/','u1_ph2.mat'],'u1_ph2_old');
        load(['output/','u2_ph2.mat'],'u2_ph2_old');
        load(['output/','u1_ph3.mat'],'u1_ph3_old');
        load(['output/','u2_ph3.mat'],'u2_ph3_old');
    end
    ph_sum1 = ph1 + ph2 + ph3;
    ph_sum2 = lambda1*ph1 + lambda2*ph2 + lambda3*ph3;
    ph_sum3 = psi1*ph1.*ph1 + psi2*ph2.*ph2 + psi3*ph3.*ph3 ...
        + 2*(1-binary)*sqrt(psi1*psi2)*ph1.*ph2 + 2*(1-binary)*sqrt(psi1*psi3)*ph1.*ph3 + 2*(1-binary)*sqrt(psi2*psi3)*ph2.*ph3;
    rho = ph1_weight*ph1(2:ny+1,2:nx+1) + ph2_weight*ph2(2:ny+1,2:nx+1) + ph3_weight*ph3(2:ny+1,2:nx+1);
    mu10_ideal = Theta*(log(ph1) + log(n_c))/H_para;
    mu10_repulsion = Theta*(lambda1*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2/H_para))/H_para;
    mu10_attraction = (2*(psi1*ph1 + (1-binary)*sqrt(psi1*psi2)*ph2 + (1-binary)*sqrt(psi1*psi3)*ph3)./(H_para*ph_sum2) ...
        - lambda1*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
        + lambda1*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) ); 
    mu10 = mu10_ideal + mu10_repulsion + mu10_attraction;
    mu1 = zeros(ny+2,nx+2);
    mu1(2:ny+1,2:nx+1) = mu10(2:ny+1,2:nx+1) - thickness1^2*diff2xy(ph1) - binary_thickness^2*diff2xy(ph2) - binary_thickness^2*diff2xy(ph3);
    mu1 = boundary_condition(mu1,'0NM','0NM');
    laplace_ph2 = zeros(ny+2,nx+2);
    laplace_ph2(2:ny+1,2:nx+1) = diff2xy(ph2);
    laplace_ph2 = boundary_condition(laplace_ph2,'0NM','0NM');
    laplace_ph3 = zeros(ny+2,nx+2);
    laplace_ph3(2:ny+1,2:nx+1) = diff2xy(ph3);
    laplace_ph3 = boundary_condition(laplace_ph3,'0NM','0NM');
    u_star_1 = zeros(ny+2,nx+2);
    u_star_1(2:ny+1,2:nx+1) = u(2:ny+1,2:nx+1) - dt*Ka*ph1(2:ny+1,2:nx+1).*diff1x(mu1)./(rho*Re);
    cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
    L1_B = cf_B*tension1*cos(pi*(ph1(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness1*(ph1(1,2:nx+1)-ph1(3,2:nx+1))/(2*dy) + binary_thickness*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy) + binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy);
    cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
    L1_T = cf_T*tension1*cos(pi*(ph1(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness1*(ph1(ny+2,2:nx+1)-ph1(ny,2:nx+1))/(2*dy) + binary_thickness*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy) + binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy);
    u_star_1 = boundary_condition(u_star_1,'0NM','GNBC');
    u_star_1(2,2:nx+1) = Bol*( L1_B.*(ph1(2,3:nx+2)-ph1(2,1:nx))/(2*dx) )/(eta*beta_uw/3) + uwB;
    u_star_1(ny+1,2:nx+1) = Bol*( L1_T.*(ph1(ny+1,3:nx+2)-ph1(ny+1,1:nx))/(2*dx) )/(eta*beta_uw/3) + uwT;
    v_star_1 = zeros(ny+2,nx+2);
    v_star_1(2:ny+1,2:nx+1) = v(2:ny+1,2:nx+1) - dt*Ka*ph1(2:ny+1,2:nx+1).*diff1y(mu1)./(rho*Re);
    v_star_1 = boundary_condition(v_star_1,'0NM','0DBC');
    temp_star_1 = diff1x(ph1.*u_star_1) + diff1y(ph1.*v_star_1);
    temp_star_1_B = u_star_1(2,2:nx+1).*( (ph1(2,3:nx+2)-ph1(2,1:nx))/(2*dx) );
    temp_star_1_T = u_star_1(ny+1,2:nx+1).*( (ph1(ny+1,3:nx+2)-ph1(ny+1,1:nx))/(2*dx) );
    rhs1_ph1 = ph1(2:ny+1,2:nx+1)/dt - temp_star_1 + beta1*diff2xy(ph1) - mobility1*binary_thickness^2*diff2xy(laplace_ph2) - mobility1*binary_thickness^2*diff2xy(laplace_ph3);
    rhs1_B_ph1 = ph1(2,2:nx+1)/dt - temp_star_1_B - vs1*binary_thickness*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy) - vs1*binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy);
    rhs1_T_ph1 = ph1(ny+1,2:nx+1)/dt - temp_star_1_T - vs1*binary_thickness*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy) - vs1*binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy);
    u1_ph1 = solve4thorder(alpha1,alpha2,mobility1,thickness1,vs1,lambda1,lambda2,lambda3,psi1,psi2,psi3,rhs1_ph1,rhs1_B_ph1,rhs1_T_ph1,u1_ph1_old,u1_ph2_old,u1_ph3_old);
    rhs2_ph1 = mobility1*diff2xy(mu10);
    cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
    rhs2_B_ph1 = -vs1*cf_B*tension1*cos(pi*(ph1(2,2:nx+1) - 1)/2 + pi/4);
    cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
    rhs2_T_ph1 = -vs1*cf_T*tension1*cos(pi*(ph1(ny+1,2:nx+1) - 1)/2 + pi/4);
    u2_ph1 = solve4thorder(alpha1,alpha2,mobility1,thickness1,vs1,lambda1,lambda2,lambda3,psi1,psi2,psi3,rhs2_ph1,rhs2_B_ph1,rhs2_T_ph1,u2_ph1_old,u2_ph2_old,u2_ph3_old);
    if ~isreal(u1_ph1) || ~isreal(u2_ph1)
        error('ph1 is imaginary')
    end
    lgm1_new = lgm_update(u1_ph1,u2_ph1,ph1,ph2,ph3,1);
    if ~isreal(lgm1_new)
        error('lgm1 is imaginary')
    end
    ph1_new = u1_ph1 + lgm1_new*u2_ph1;
    ph1_new = boundary_condition(ph1_new,'0NM','RBC');
    ph1_new(1,2:nx+1) = ph1_new(3,2:nx+1) - 2*dy*( (ph1_new(2,2:nx+1)-ph1(2,2:nx+1))/dt ...
                        + temp_star_1_B + lgm1_new*vs1*cf_B*tension1*cos(pi*ph1(2,2:nx+1)/2) ...
                        + vs1*binary_thickness*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy) + vs1*binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy) )/(thickness1*vs1);
    ph1_new(ny+2,2:nx+1) = ph1_new(ny,2:nx+1) - 2*dy*( (ph1_new(ny+1,2:nx+1)-ph1(ny+1,2:nx+1))/dt ...
                        + temp_star_1_T + lgm1_new*vs1*cf_T*tension1*cos(pi*ph1(ny+1,2:nx+1)/2) ...
                        + vs1*binary_thickness*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy) + vs1*binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy) )/(thickness1*vs1);
    mu1_new = zeros(ny+2,nx+2);
    mu1_new(2:ny+1,2:nx+1) = lgm1_new*mu10(2:ny+1,2:nx+1) - thickness1^2*diff2xy(ph1_new) - binary_thickness^2*diff2xy(ph2) - binary_thickness^2*diff2xy(ph3);
    mu1_new = boundary_condition(mu1_new,'0NM','0NM');
    ph_sum1 = ph1_new + ph2 + ph3;
    ph_sum2 = lambda1*ph1_new + lambda2*ph2 + lambda3*ph3;
    ph_sum3 = psi1*ph1_new.*ph1_new + psi2*ph2.*ph2 + psi3*ph3.*ph3 ...
        + 2*(1-binary)*sqrt(psi1*psi2)*ph1_new.*ph2 + 2*(1-binary)*sqrt(psi1*psi3)*ph1_new.*ph3 + 2*(1-binary)*sqrt(psi2*psi3)*ph2.*ph3;
    mu20_ideal = Theta*(log(ph2) + log(n_c))/H_para;
    mu20_repulsion = Theta*(lambda2*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2/H_para))/H_para;
    mu20_attraction = (2*((1-binary)*sqrt(psi1*psi2)*ph1_new + psi2*ph2 + (1-binary)*sqrt(psi2*psi3)*ph3)./(H_para*ph_sum2) ...
        - lambda2*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
        + lambda2*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) ); 
    mu20 = mu20_ideal + mu20_repulsion + mu20_attraction;
    mu2 = zeros(ny+2,nx+2);
    mu2(2:ny+1,2:nx+1) = mu20(2:ny+1,2:nx+1) - thickness2^2*diff2xy(ph2) - binary_thickness^2*diff2xy(ph1_new) - binary_thickness^2*diff2xy(ph3);
    mu2 = boundary_condition(mu2,'0NM','0NM');
    laplace_ph1 = zeros(ny+2,nx+2);
    laplace_ph1(2:ny+1,2:nx+1) = diff2xy(ph1_new);
    laplace_ph1 = boundary_condition(laplace_ph1,'0NM','0NM');
    u_star_2 = zeros(ny+2,nx+2);
    u_star_2(2:ny+1,2:nx+1) = u_star_1(2:ny+1,2:nx+1) - dt*Ka*ph2(2:ny+1,2:nx+1).*diff1x(mu2)./(rho*Re);
    cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
    L2_B = cf_B*tension2*cos(pi*(ph2(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness2*(ph2(1,2:nx+1)-ph2(3,2:nx+1))/(2*dy) + binary_thickness*(ph1_new(1,2:nx+1)-ph1_new(3,2:nx+1))/(2*dy) + binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy);
    cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
    L2_T = cf_T*tension2*cos(pi*(ph2(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness2*(ph2(ny+2,2:nx+1)-ph2(ny,2:nx+1))/(2*dy) + binary_thickness*(ph1_new(ny+2,2:nx+1)-ph1_new(ny,2:nx+1))/(2*dy) + binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy);
    u_star_2 = boundary_condition(u_star_2,'0NM','GNBC');
    u_star_2(2,2:nx+1) = Bol*( L2_B.*(ph2(2,3:nx+2)-ph2(2,1:nx))/(2*dx) )/(eta*beta_uw/3) + uwB;
    u_star_2(ny+1,2:nx+1) = Bol*( L2_T.*(ph2(ny+1,3:nx+2)-ph2(ny+1,1:nx))/(2*dx) )/(eta*beta_uw/3) + uwT;
    v_star_2 = zeros(ny+2,nx+2);
    v_star_2(2:ny+1,2:nx+1) =  v_star_1(2:ny+1,2:nx+1) - dt*Ka*ph2(2:ny+1,2:nx+1).*diff1y(mu2)./(rho*Re);
    v_star_2 = boundary_condition(v_star_2,'0NM','0DBC');
    temp_star_2 = diff1x(ph2.*u_star_2) + diff1y(ph2.*v_star_2);
    temp_star_2_B = u_star_2(2,2:nx+1).*( (ph2(2,3:nx+2)-ph2(2,1:nx))/(2*dx) );
    temp_star_2_T = u_star_2(ny+1,2:nx+1).*( (ph2(ny+1,3:nx+2)-ph2(ny+1,1:nx))/(2*dx) );
    rhs1_ph2 = ph2(2:ny+1,2:nx+1)/dt - temp_star_2 + beta2*diff2xy(ph2) - mobility2*binary_thickness^2*diff2xy(laplace_ph1) - mobility2*binary_thickness^2*diff2xy(laplace_ph3);
    rhs1_B_ph2 = ph2(2,2:nx+1)/dt - temp_star_2_B - vs2*binary_thickness*(ph1_new(1,2:nx+1)-ph1_new(3,2:nx+1))/(2*dy) - vs2*binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy);
    rhs1_T_ph2 = ph2(ny+1,2:nx+1)/dt - temp_star_2_T - vs2*binary_thickness*(ph1_new(ny+2,2:nx+1)-ph1_new(ny,2:nx+1))/(2*dy) - vs2*binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy);
    u1_ph2 = solve4thorder(alpha1,alpha2,mobility2,thickness2,vs2,lambda2,lambda1,lambda3,psi2,psi1,psi3,rhs1_ph2,rhs1_B_ph2,rhs1_T_ph2,u1_ph2_old,u1_ph1_old,u1_ph3_old);
    rhs2_ph2 = mobility2*diff2xy(mu20);
    rhs2_B_ph2 = -vs2*cf_B*tension2*cos(pi*(ph2(2,2:nx+1) - 1)/2 + pi/4);
    rhs2_T_ph2 = -vs2*cf_T*tension2*cos(pi*(ph2(ny+1,2:nx+1) - 1)/2 + pi/4);
    u2_ph2 = solve4thorder(alpha1,alpha2,mobility2,thickness2,vs2,lambda2,lambda1,lambda3,psi2,psi1,psi3,rhs2_ph2,rhs2_B_ph2,rhs2_T_ph2,u2_ph2_old,u2_ph1_old,u2_ph3_old);
    if ~isreal(u1_ph2) || ~isreal(u2_ph2)
        error('ph2 is imaginary')
    end
    lgm2_new = lgm_update(u1_ph2,u2_ph2,ph1_new,ph2,ph3,2);

    if ~isreal(lgm2_new)
        error('lgm2 is imaginary')
    end
    ph2_new = u1_ph2 + lgm2_new*u2_ph2;
    ph2_new = boundary_condition(ph2_new,'0NM','RBC');
    ph2_new(1,2:nx+1) = ph2_new(3,2:nx+1) - 2*dy*( (ph2_new(2,2:nx+1)-ph2(2,2:nx+1))/dt ...
                        + temp_star_2_B + lgm2_new*vs2*cf_B*tension2*cos(pi*ph2(2,2:nx+1)/2) ...
                        + vs2*binary_thickness*(ph1_new(1,2:nx+1)-ph1_new(3,2:nx+1))/(2*dy) + vs2*binary_thickness*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy) )/(thickness2*vs2);
    ph2_new(ny+2,2:nx+1) = ph2_new(ny,2:nx+1) - 2*dy*( (ph2_new(ny+1,2:nx+1)-ph2(ny+1,2:nx+1))/dt ...
                        + temp_star_2_T + lgm2_new*vs2*cf_T*tension2*cos(pi*ph2(ny+1,2:nx+1)/2) ...
                        + vs2*binary_thickness*(ph1_new(ny+2,2:nx+1)-ph1_new(ny,2:nx+1))/(2*dy) + vs2*binary_thickness*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy) )/(thickness2*vs2);
    mu2_new = zeros(ny+2,nx+2);
    mu2_new(2:ny+1,2:nx+1) = lgm2_new*mu20(2:ny+1,2:nx+1) - thickness2^2*diff2xy(ph2_new) - binary_thickness^2*diff2xy(ph1_new) - binary_thickness^2*diff2xy(ph3);
    mu2_new = boundary_condition(mu2_new,'0NM','0NM');
    ph_sum1 = ph1_new + ph2_new + ph3;
    ph_sum2 = lambda1*ph1_new + lambda2*ph2_new + lambda3*ph3;
    ph_sum3 = psi1*ph1_new.*ph1_new + psi2*ph2_new.*ph2_new + psi3*ph3.*ph3 ...
        + 2*(1-binary)*sqrt(psi1*psi2)*ph1_new.*ph2_new + 2*(1-binary)*sqrt(psi1*psi3)*ph1_new.*ph3 + 2*(1-binary)*sqrt(psi2*psi3)*ph2_new.*ph3;
    mu30_ideal = Theta*(log(ph3) + log(n_c))/H_para;
    mu30_repulsion = Theta*(lambda3*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2/H_para))/H_para;
    mu30_attraction = (2*((1-binary)*sqrt(psi1*psi3)*ph1_new + (1-binary)*sqrt(psi2*psi3)*ph2 + psi3*ph3)./(H_para*ph_sum2) ...
        - lambda3*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
        + lambda3*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) ); 
    mu30 = mu30_ideal + mu30_repulsion + mu30_attraction;
    mu3 = zeros(ny+2,nx+2);
    mu3(2:ny+1,2:nx+1) = mu30(2:ny+1,2:nx+1) - thickness3^2*diff2xy(ph3) - binary_thickness^2*diff2xy(ph1_new) - binary_thickness^2*diff2xy(ph2_new);
    mu3 = boundary_condition(mu3,'0NM','0NM');
    laplace_ph2 = zeros(ny+2,nx+2);
    laplace_ph2(2:ny+1,2:nx+1) = diff2xy(ph2_new);
    laplace_ph2 = boundary_condition(laplace_ph2,'0NM','0NM');
    u_star_3 = zeros(ny+2,nx+2);
    u_star_3(2:ny+1,2:nx+1) = u_star_2(2:ny+1,2:nx+1) - dt*Ka*ph3(2:ny+1,2:nx+1).*diff1x(mu3)./(rho*Re);
    cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
    L3_B = cf_B*tension3*cos(pi*(ph3(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness3*(ph3(1,2:nx+1)-ph3(3,2:nx+1))/(2*dy) + binary_thickness*(ph1_new(1,2:nx+1)-ph1_new(3,2:nx+1))/(2*dy) + binary_thickness*(ph2_new(1,2:nx+1)-ph2_new(3,2:nx+1))/(2*dy);
    cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
    L3_T = cf_T*tension3*cos(pi*(ph3(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness3*(ph3(ny+2,2:nx+1)-ph3(ny,2:nx+1))/(2*dy) + binary_thickness*(ph1_new(ny+2,2:nx+1)-ph1_new(ny,2:nx+1))/(2*dy) + binary_thickness*(ph2_new(ny+2,2:nx+1)-ph2_new(ny,2:nx+1))/(2*dy);
    u_star_3 = boundary_condition(u_star_3,'0NM','GNBC');
    u_star_3(2,2:nx+1) = Bol*( L3_B.*(ph3(2,3:nx+2)-ph3(2,1:nx))/(2*dx) )/(eta*beta_uw/3) + uwB;
    u_star_3(ny+1,2:nx+1) = Bol*( L3_T.*(ph3(ny+1,3:nx+2)-ph3(ny+1,1:nx))/(2*dx) )/(eta*beta_uw/3) + uwT;
    v_star_3 = zeros(ny+2,nx+2);
    v_star_3(2:ny+1,2:nx+1) =  v_star_2(2:ny+1,2:nx+1) - dt*Ka*ph3(2:ny+1,2:nx+1).*diff1y(mu3)./(rho*Re);
    v_star_3 = boundary_condition(v_star_3,'0NM','0DBC');
    temp_star_3 = diff1x(ph3.*u_star_3) + diff1y(ph3.*v_star_3);
    temp_star_3_B = u_star_3(2,2:nx+1).*( (ph3(2,3:nx+2)-ph3(2,1:nx))/(2*dx) );
    temp_star_3_T = u_star_3(ny+1,2:nx+1).*( (ph3(ny+1,3:nx+2)-ph3(ny+1,1:nx))/(2*dx) );
    rhs1_ph3 = ph3(2:ny+1,2:nx+1)/dt - temp_star_3 + beta3*diff2xy(ph3) - mobility3*binary_thickness^2*diff2xy(laplace_ph1) - mobility3*binary_thickness^2*diff2xy(laplace_ph2);
    rhs1_B_ph3 = ph3(2,2:nx+1)/dt - temp_star_3_B - vs3*binary_thickness*(ph1_new(1,2:nx+1)-ph1_new(3,2:nx+1))/(2*dy) - vs3*binary_thickness*(ph2_new(1,2:nx+1)-ph2_new(3,2:nx+1))/(2*dy);
    rhs1_T_ph3 = ph3(ny+1,2:nx+1)/dt - temp_star_3_T - vs3*binary_thickness*(ph1_new(ny+2,2:nx+1)-ph1_new(ny,2:nx+1))/(2*dy) - vs3*binary_thickness*(ph2_new(ny+2,2:nx+1)-ph2_new(ny,2:nx+1))/(2*dy);
    u1_ph3 = solve4thorder(alpha1,alpha2,mobility3,thickness3,vs3,lambda3,lambda1,lambda2,psi3,psi1,psi2,rhs1_ph3,rhs1_B_ph3,rhs1_T_ph3,u1_ph3_old,u1_ph1_old,u1_ph2_old);
    rhs2_ph3 = mobility3*diff2xy(mu30);
    rhs2_B_ph3 = -vs3*cf_B*tension3*cos(pi*(ph3(2,2:nx+1) - 1)/2 + pi/4);
    rhs2_T_ph3 = -vs3*cf_T*tension3*cos(pi*(ph3(ny+1,2:nx+1) - 1)/2 + pi/4);
    u2_ph3 = solve4thorder(alpha1,alpha2,mobility3,thickness3,vs3,lambda3,lambda1,lambda2,psi3,psi1,psi2,rhs2_ph3,rhs2_B_ph3,rhs2_T_ph3,u2_ph3_old,u2_ph1_old,u2_ph2_old);
    if ~isreal(u1_ph3) || ~isreal(u2_ph3)
        error('ph3 is imaginary')
    end
    lgm3_new = lgm_update(u1_ph3,u2_ph3,ph1_new,ph2_new,ph3,3);
    if ~isreal(lgm3_new)
        error('lgm3 is imaginary')
    end
    ph3_new = u1_ph3 + lgm3_new*u2_ph3;
    ph3_new = boundary_condition(ph3_new,'0NM','RBC');
    ph3_new(1,2:nx+1) = ph3_new(3,2:nx+1) - 2*dy*( (ph3_new(2,2:nx+1)-ph3(2,2:nx+1))/dt ...
                        + temp_star_3_B + lgm3_new*vs3*cf_B*tension3*cos(pi*ph3(2,2:nx+1)/2) ...
                        + vs3*binary_thickness*(ph1_new(1,2:nx+1)-ph1_new(3,2:nx+1))/(2*dy) + vs3*binary_thickness*(ph2_new(1,2:nx+1)-ph2_new(3,2:nx+1))/(2*dy) )/(thickness3*vs3);
    ph3_new(ny+2,2:nx+1) = ph3_new(ny,2:nx+1) - 2*dy*( (ph3_new(ny+1,2:nx+1)-ph3(ny+1,2:nx+1))/dt ...
                        + temp_star_3_T + lgm3_new*vs3*cf_T*tension3*cos(pi*ph3(ny+1,2:nx+1)/2) ...
                        + vs3*binary_thickness*(ph1_new(ny+2,2:nx+1)-ph1_new(ny,2:nx+1))/(2*dy) + vs3*binary_thickness*(ph2_new(ny+2,2:nx+1)-ph2_new(ny,2:nx+1))/(2*dy) )/(thickness3*vs3);
    mu3_new = zeros(ny+2,nx+2);
    mu3_new(2:ny+1,2:nx+1) = lgm3_new*mu30(2:ny+1,2:nx+1) - thickness3^2*diff2xy(ph3_new) - binary_thickness^2*diff2xy(ph1_new) - binary_thickness^2*diff2xy(ph2_new);
    mu3_new = boundary_condition(mu3_new,'0NM','0NM');
    u1_ph1_old = u1_ph1;
    u2_ph1_old = u2_ph1;
    u1_ph2_old = u1_ph2;
    u2_ph2_old = u2_ph2;
    u1_ph3_old = u1_ph3;
    u2_ph3_old = u2_ph3;
    save(['output/','u1_ph1.mat'],'u1_ph1_old');
    save(['output/','u2_ph1.mat'],'u2_ph1_old');
    save(['output/','u1_ph2.mat'],'u1_ph2_old');
    save(['output/','u2_ph2.mat'],'u2_ph2_old');
    save(['output/','u1_ph3.mat'],'u1_ph3_old');
    save(['output/','u2_ph3.mat'],'u2_ph3_old');
end
function u = solve4thorder(alpha1,alpha2,para_a,para_b,para_c,lambda_u,lambda_v,lambda_t,psi_u,psi_v,psi_t,rhs,rhs_B,rhs_T,u_old,v_old,t_old)
    load(['output/','global.mat'],'nx','ny','dy','dt','H_para','Theta','n_c','binary');
    u_sum1 = u_old + v_old + t_old;
    u_sum2 = lambda_u*u_old + lambda_v*v_old + lambda_t*t_old;
    u_sum3 = psi_u*u_old.*u_old + psi_v*v_old.*v_old + psi_t*t_old.*t_old ...
        + 2*(1-binary)*sqrt(psi_u*psi_v)*u_old.*v_old + 2*(1-binary)*sqrt(psi_u*psi_t)*u_old.*t_old + 2*(1-binary)*sqrt(psi_v*psi_t)*v_old.*t_old;
    temp_ideal = Theta*(log(u_old + 1) + log(n_c))/H_para;
    temp_repulsion = Theta*(lambda_u*u_sum1./(H_para-u_sum2) - log(1-u_sum2/H_para))/H_para;
    temp_attraction = (2*(psi_u*u_old + (1-binary)*sqrt(psi_u*psi_v)*v_old + (1-binary)*sqrt(psi_u*psi_t)*t_old)./(H_para*u_sum2) ...
        - lambda_u*u_sum3./(H_para*u_sum2.^2)).*log((H_para+(1-sqrt(2))*u_sum2)./(H_para+(1+sqrt(2))*u_sum2))/(2*sqrt(2)) ...
        + lambda_u*u_sum3./( u_sum2.*((sqrt(2)-1)*u_sum2-H_para).*((sqrt(2)+1)*u_sum2+H_para) );  
    temp = temp_ideal + temp_repulsion + temp_attraction - alpha1*u_old;
    rhs = rhs + alpha2*temp(2:ny+1,2:nx+1) - para_a*diff2xy(temp);
    A = assemble(alpha2,para_a,[],ny,nx,'const');
    [psi_vec,info] = gmres(A,rhs(:),30,1.0e-10);
    if info ~= 0
        fprintf('The gmres iteration can not converge!\n');
        fprintf('The info_flag is %d\n',info);
        error('The gmres iteration can not converge!\n')
    end
    psi = reshape(psi_vec,ny,nx);
    psi = psi - temp(2:ny+1,2:nx+1);
    psi(1,:) = psi(1,:) + 2*para_b*rhs_B/(dy*para_c);
    psi(ny,:) = psi(ny,:) + 2*para_b*rhs_T/(dy*para_c);
    A = assemble(alpha1,para_b,para_c,ny,nx,'RBC');
    [u_vec, info] = gmres(A,psi(:),30,1.0e-10);
    if info ~= 0
        fprintf('The gmres iteration can not converge!\n');
        fprintf('The info_flag is %d\n',info);
        error('The gmres iteration can not converge!\n')
    end
    u = zeros(ny+2, nx+2);
    u(2:ny+1, 2:nx+1) = reshape(u_vec,ny,nx);
    u = boundary_condition(u,'0NM','RBC');
    u(1,2:nx+1) = u(3,2:nx+1) + 2*dy*(rhs_B - u(2,2:nx+1)/dt)/(para_b*para_c);
    u(ny+2,2:nx+1) = u(ny,2:nx+1) + 2*dy*(rhs_T - u(ny+1,2:nx+1)/dt)/(para_b*para_c);
end
function lgm = lgm_update(u1,u2,ph1,ph2,ph3,ph_flag)
    lgm = 1.0;
    iter_max = 500;
    tol = 1.0e-6;
    for i = 0:iter_max
        if i == 0
            res_f = nonlinear_inner_product('f',lgm,u1,u2,ph1,ph2,ph3,ph_flag);
            if abs(res_f) < tol
                break
            end
            res_df = nonlinear_inner_product('df',lgm,u1,u2,ph1,ph2,ph3,ph_flag);
            lgm_new = lgm - res_f/res_df;
            res_f_new = nonlinear_inner_product('f',lgm_new,u1,u2,ph1,ph2,ph3,ph_flag);
        else
            res_df = nonlinear_inner_product('df',lgm,u1,u2,ph1,ph2,ph3,ph_flag);
            lgm_new = lgm - res_f/res_df;
            res_f_new = nonlinear_inner_product('f',lgm_new,u1,u2,ph1,ph2,ph3,ph_flag);
        end
        res_f = res_f_new;
        lgm = lgm_new;
        if abs(res_f) < tol
            break
        end
        if i == iter_max
            error('the maximum number of iterations has been reached!')
        end
    end
end
function temp = nonlinear_inner_product(function_type,lgm,u1,u2,ph1,ph2,ph3,ph_flag)
    load(['output/','global.mat'],'nx','ny','dx','dy','weight','Theta','H_para','n_c','angle_B','angle_T','tension1','tension2','tension3', ...
        'lambda1','lambda2','lambda3','psi1','psi2','psi3','binary');
    u1 = u1(2:ny+1,2:nx+1);
    u2 = u2(2:ny+1,2:nx+1);
    ph1 = ph1(2:ny+1,2:nx+1);
    ph2 = ph2(2:ny+1,2:nx+1);
    ph3 = ph3(2:ny+1,2:nx+1);
    ph_lgm = u1 + lgm*u2;
    ph_sum1 = ph1 + ph2 + ph3;
    ph_sum2 = lambda1*ph1 + lambda2*ph2 + lambda3*ph3;
    ph_sum3 = psi1*ph1.*ph1 + psi2*ph2.*ph2 + psi3*ph3.*ph3 ...
        + 2*(1-binary)*sqrt(psi1*psi2)*ph1.*ph2 + 2*(1-binary)*sqrt(psi1*psi3)*ph1.*ph3 + 2*(1-binary)*sqrt(psi2*psi3)*ph2.*ph3;
    f0_ideal = Theta*(ph1.*(log(ph1) + log(n_c) - 1) + ph2.*(log(ph2) + log(n_c) - 1) + ph3.*(log(ph3) + log(n_c) - 1))/H_para;
    f0_repulsion = -Theta*(ph_sum1.*log(1-ph_sum2./H_para))./H_para;
    f0_attraction = ph_sum3.*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))./(2*sqrt(2)*H_para*ph_sum2);
    f0 = f0_ideal + f0_repulsion + f0_attraction;
    cf_B = -Theta*cos(angle_B*pi/180)/(6*sqrt(2)*H_para);
    cf_T = -Theta*cos(angle_T*pi/180)/(6*sqrt(2)*H_para);
    g_B = cf_B*(tension1*sin(pi*(ph1(1,:) - 1)/2 + pi/4) + tension2*sin(pi*(ph2(1,:) - 1)/2 + pi/4) + tension3*sin(pi*(ph3(1,:) - 1)/2 + pi/4));
    g_T = cf_T*(tension1*sin(pi*(ph1(ny,:) - 1)/2 + pi/4) + tension2*sin(pi*(ph2(ny,:) - 1)/2 + pi/4) + tension3*sin(pi*(ph3(ny,:) - 1)/2 + pi/4));
    if ph_flag == 1
        mu0_ideal = Theta*(log(ph1) + log(n_c))/H_para;
        mu0_repulsion = Theta*(lambda1*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2./H_para))./H_para;
        mu0_attraction = (2*(psi1*ph1 + (1-binary)*sqrt(psi1*psi2)*ph2 + (1-binary)*sqrt(psi1*psi3)*ph3)./(H_para*ph_sum2) ...
            - lambda1*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
            + lambda1*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) ); 
        mu0 = mu0_ideal + mu0_repulsion + mu0_attraction;
        cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
        cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
        g_p_B = cf_B*tension1*cos(pi*(ph1(1,:) - 1)/2 + pi/4);
        g_p_T = cf_T*tension1*cos(pi*(ph1(ny,:) - 1)/2 + pi/4);
        ph_lgm_sum1 = ph_lgm + ph2 + ph3;
        ph_lgm_sum2 = lambda1*ph_lgm + lambda2*ph2 + lambda3*ph3;
        ph_lgm_sum3 = psi1*ph_lgm.*ph_lgm + psi2*ph2.*ph2 + psi3*ph3.*ph3 ...
            + 2*(1-binary)*sqrt(psi1*psi2)*ph_lgm.*ph2 + 2*(1-binary)*sqrt(psi1*psi3)*ph_lgm.*ph3 + 2*(1-binary)*sqrt(psi2*psi3)*ph2.*ph3;
        if strcmp(function_type,'f') == 1
            f0_lgm_ideal = Theta*(ph_lgm.*(log(ph_lgm) + log(n_c) - 1) + ph2.*(log(ph2) + log(n_c) - 1) + ph3.*(log(ph3) + log(n_c) - 1))/H_para;
            f0_lgm_repulsion = -Theta*(ph_lgm_sum1.*log(1-ph_lgm_sum2./H_para))./H_para;
            f0_lgm_attraction = ph_lgm_sum3.*log((H_para+(1-sqrt(2))*ph_lgm_sum2)./(H_para+(1+sqrt(2))*ph_lgm_sum2))./(2*sqrt(2)*H_para*ph_lgm_sum2);
            f0_lgm = f0_lgm_ideal + f0_lgm_repulsion + f0_lgm_attraction;
            cf_B = -Theta*cos(angle_B*pi/180)/(6*sqrt(2)*H_para);
            cf_T = -Theta*cos(angle_T*pi/180)/(6*sqrt(2)*H_para);
            g_B_lgm = cf_B*(tension1*sin(pi*(ph_lgm(1,:) - 1)/2 + pi/4) + tension2*sin(pi*(ph2(1,:) - 1)/2 + pi/4) + tension3*sin(pi*(ph3(1,:) - 1)/2 + pi/4));
            g_T_lgm = cf_T*(tension1*sin(pi*(ph_lgm(ny,:) - 1)/2 + pi/4) + tension2*sin(pi*(ph2(ny,:) - 1)/2 + pi/4) + tension3*sin(pi*(ph3(ny,:) - 1)/2 + pi/4));
            temp1 = sum(weight.*(f0_lgm - f0),'all')*dx*dy;
            temp2 = sum(weight.*mu0.*(ph_lgm - ph1),'all')*dx*dy;
            temp3 = sum(weight(1,:).*(g_B_lgm - g_B),'all')*dx + ...
                    sum(weight(ny,:).*(g_T_lgm - g_T),'all')*dx; 
            temp4 = sum(weight(1,:).*g_p_B.*(ph_lgm(1,:) - ph1(1,:)),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T.*(ph_lgm(ny,:) - ph1(ny,:)),'all')*dx;
            temp = temp1 + temp3 - lgm*(temp2 + temp4);
        elseif strcmp(function_type,'df') == 1
            mu0_lgm_ideal = Theta*(log(ph_lgm) + log(n_c))/H_para;
            mu0_lgm_repulsion = Theta*(lambda1*ph_lgm_sum1./(H_para-ph_lgm_sum2) - log(1-ph_lgm_sum2./H_para))./H_para;
            mu0_lgm_attraction = (2*(psi1*ph_lgm + (1-binary)*sqrt(psi1*psi2)*ph2 + (1-binary)*sqrt(psi1*psi3)*ph3)./(H_para*ph_lgm_sum2) ...
                - lambda1*ph_lgm_sum3./(H_para*ph_lgm_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_lgm_sum2)./(H_para+(1+sqrt(2))*ph_lgm_sum2))/(2*sqrt(2)) ...
                + lambda1*ph_lgm_sum3./( ph_lgm_sum2.*((sqrt(2)-1)*ph_lgm_sum2-H_para).*((sqrt(2)+1)*ph_lgm_sum2+H_para) ); 
            mu0_lgm = mu0_lgm_ideal + mu0_lgm_repulsion + mu0_lgm_attraction;
            cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
            cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
            g_p_B_lgm = cf_B*tension1*cos(pi*(ph_lgm(1,:) - 1)/2 + pi/4);
            g_p_T_lgm = cf_T*tension1*cos(pi*(ph_lgm(ny,:) - 1)/2 + pi/4);
            temp1 = sum(weight.*mu0_lgm.*u2,'all')*dx*dy;
            temp2 = sum(weight.*mu0.*(ph_lgm - ph1),'all')*dx*dy;
            temp3 = sum(weight.*mu0.*u2,'all')*dx*dy;
            temp4 = sum(weight(1,:).*g_p_B_lgm.*u2(1,:),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T_lgm.*u2(ny,:),'all')*dx;
            temp5 = sum(weight(1,:).*g_p_B.*(ph_lgm(1,:) - ph1(1,:)),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T.*(ph_lgm(ny,:) - ph1(ny,:)),'all')*dx;
            temp6 = sum(weight(1,:).*g_p_B.*u2(1,:),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T.*u2(ny,:),'all')*dx;
            temp = temp1 + temp4 - temp2 - temp5 - lgm*(temp3 + temp6);
        else
            error('wrong input in function type')
        end
    elseif ph_flag == 2
        mu0_ideal = Theta*(log(ph2) + log(n_c))/H_para;
        mu0_repulsion = Theta*(lambda2*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2./H_para))./H_para;
        mu0_attraction = (2*((1-binary)*sqrt(psi1*psi2)*ph1 + psi2*ph2 + (1-binary)*sqrt(psi2*psi3)*ph3)./(H_para*ph_sum2) ...
            - lambda2*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
            + lambda2*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) );
        mu0 = mu0_ideal + mu0_repulsion + mu0_attraction;
        cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
        cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
        g_p_B = cf_B*tension2*cos(pi*(ph2(1,:) - 1)/2 + pi/4);
        g_p_T = cf_T*tension2*cos(pi*(ph2(ny,:) - 1)/2 + pi/4);
        ph_lgm_sum1 = ph1 + ph_lgm + ph3;
        ph_lgm_sum2 = lambda1*ph1 + lambda2*ph_lgm + lambda3*ph3;
        ph_lgm_sum3 = psi1*ph1.*ph1 + psi2*ph_lgm.*ph_lgm + psi3*ph3.*ph3 ...
            + 2*(1-binary)*sqrt(psi1*psi2)*ph1.*ph_lgm + 2*(1-binary)*sqrt(psi1*psi3)*ph1.*ph3 + 2*(1-binary)*sqrt(psi2*psi3)*ph_lgm.*ph3;
        if strcmp(function_type,'f') == 1
            f0_lgm_ideal = Theta*(ph1.*(log(ph1) + log(n_c) - 1) + ph_lgm.*(log(ph_lgm) + log(n_c) - 1) + ph3.*(log(ph3) + log(n_c) - 1))/H_para;
            f0_lgm_repulsion = -Theta*(ph_lgm_sum1.*log(1-ph_lgm_sum2./H_para))./H_para;
            f0_lgm_attraction = ph_lgm_sum3.*log((H_para+(1-sqrt(2))*ph_lgm_sum2)./(H_para+(1+sqrt(2))*ph_lgm_sum2))./(2*sqrt(2)*H_para*ph_lgm_sum2);
            f0_lgm = f0_lgm_ideal + f0_lgm_repulsion + f0_lgm_attraction;
            cf_B = -Theta*cos(angle_B*pi/180)/(6*sqrt(2)*H_para);
            cf_T = -Theta*cos(angle_T*pi/180)/(6*sqrt(2)*H_para);
            g_B_lgm = cf_B*(tension1*sin(pi*(ph1(1,:) - 1)/2 + pi/4) + tension2*sin(pi*(ph_lgm(1,:) - 1)/2 + pi/4) + tension3*sin(pi*(ph3(1,:) - 1)/2 + pi/4));
            g_T_lgm = cf_T*(tension1*sin(pi*(ph1(ny,:) - 1)/2 + pi/4) + tension2*sin(pi*(ph_lgm(ny,:) - 1)/2 + pi/4) + tension3*sin(pi*(ph3(ny,:) - 1)/2 + pi/4));
            temp1 = sum(weight.*(f0_lgm - f0),'all')*dx*dy;
            temp2 = sum(weight.*mu0.*(ph_lgm - ph2),'all')*dx*dy;
            temp3 = sum(weight(1,:).*(g_B_lgm - g_B),'all')*dx + ...
                    sum(weight(ny,:).*(g_T_lgm - g_T),'all')*dx; 
            temp4 = sum(weight(1,:).*g_p_B.*(ph_lgm(1,:) - ph2(1,:)),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T.*(ph_lgm(ny,:) - ph2(ny,:)),'all')*dx;
            temp = temp1 + temp3 - lgm*(temp2 + temp4);
        elseif strcmp(function_type,'df') == 1
            mu0_lgm_ideal = Theta*(log(ph_lgm) + log(n_c))/H_para;
            mu0_lgm_repulsion = Theta*(lambda2*ph_lgm_sum1./(H_para-ph_lgm_sum2) - log(1-ph_lgm_sum2./H_para))./H_para;
            mu0_lgm_attraction = (2*((1-binary)*sqrt(psi1*psi2)*ph1 + psi2*ph_lgm + (1-binary)*sqrt(psi2*psi3)*ph3)./(H_para*ph_lgm_sum2) ...
                - lambda2*ph_lgm_sum3./(H_para*ph_lgm_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_lgm_sum2)./(H_para+(1+sqrt(2))*ph_lgm_sum2))/(2*sqrt(2)) ...
                + lambda2*ph_lgm_sum3./( ph_lgm_sum2.*((sqrt(2)-1)*ph_lgm_sum2-H_para).*((sqrt(2)+1)*ph_lgm_sum2+H_para) ); 
            mu0_lgm = mu0_lgm_ideal + mu0_lgm_repulsion + mu0_lgm_attraction;
            cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
            cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
            g_p_B_lgm = cf_B*tension2*cos(pi*(ph_lgm(1,:) - 1)/2 + pi/4);
            g_p_T_lgm = cf_T*tension2*cos(pi*(ph_lgm(ny,:) - 1)/2 + pi/4);
            temp1 = sum(weight.*mu0_lgm.*u2,'all')*dx*dy;
            temp2 = sum(weight.*mu0.*(ph_lgm - ph2),'all')*dx*dy;
            temp3 = sum(weight.*mu0.*u2,'all')*dx*dy;
            temp4 = sum(weight(1,:).*g_p_B_lgm.*u2(1,:),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T_lgm.*u2(ny,:),'all')*dx;
            temp5 = sum(weight(1,:).*g_p_B.*(ph_lgm(1,:) - ph2(1,:)),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T.*(ph_lgm(ny,:) - ph2(ny,:)),'all')*dx;
            temp6 = sum(weight(1,:).*g_p_B.*u2(1,:),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T.*u2(ny,:),'all')*dx;
            temp = temp1 + temp4 - temp2 - temp5 - lgm*(temp3 + temp6);
        else
            error('wrong input in function type')
        end
    elseif ph_flag == 3
        mu0_ideal = Theta*(log(ph3) + log(n_c))/H_para;
        mu0_repulsion = Theta*(lambda3*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2./H_para))./H_para;
        mu0_attraction = (2*((1-binary)*sqrt(psi1*psi3)*ph1 + (1-binary)*sqrt(psi2*psi3)*ph2 + psi3*ph3)./(H_para*ph_sum2) ...
            - lambda3*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
            + lambda3*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) );
        mu0 = mu0_ideal + mu0_repulsion + mu0_attraction;
        cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
        cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
        g_p_B = cf_B*tension3*cos(pi*(ph3(1,:) - 1)/2 + pi/4);
        g_p_T = cf_T*tension3*cos(pi*(ph3(ny,:) - 1)/2 + pi/4);
        ph_lgm_sum1 = ph1 + ph2 + ph_lgm;
        ph_lgm_sum2 = lambda1*ph1 + lambda2*ph2 + lambda3*ph_lgm;
        ph_lgm_sum3 = psi1*ph1.*ph1 + psi2*ph2.*ph2 + psi3*ph_lgm.*ph_lgm ...
            + 2*(1-binary)*sqrt(psi1*psi2)*ph1.*ph2 + 2*(1-binary)*sqrt(psi1*psi3)*ph1.*ph_lgm + 2*(1-binary)*sqrt(psi2*psi3)*ph2.*ph_lgm;
        if strcmp(function_type,'f') == 1
            f0_lgm_ideal = Theta*(ph1.*(log(ph1) + log(n_c) - 1) + ph2.*(log(ph2) + log(n_c) - 1) + ph_lgm.*(log(ph_lgm) + log(n_c) - 1))/H_para;
            f0_lgm_repulsion = -Theta*(ph_lgm_sum1.*log(1-ph_lgm_sum2./H_para))./H_para;
            f0_lgm_attraction = ph_lgm_sum3.*log((H_para+(1-sqrt(2))*ph_lgm_sum2)./(H_para+(1+sqrt(2))*ph_lgm_sum2))./(2*sqrt(2)*H_para*ph_lgm_sum2);
            f0_lgm = f0_lgm_ideal + f0_lgm_repulsion + f0_lgm_attraction;
            cf_B = -Theta*cos(angle_B*pi/180)/(6*sqrt(2)*H_para);
            cf_T = -Theta*cos(angle_T*pi/180)/(6*sqrt(2)*H_para);
            g_B_lgm = cf_B*(tension1*sin(pi*(ph1(1,:) - 1)/2 + pi/4) + tension2*sin(pi*(ph2(1,:) - 1)/2 + pi/4) + tension3*sin(pi*(ph_lgm(1,:) - 1)/2 + pi/4));
            g_T_lgm = cf_T*(tension1*sin(pi*(ph1(ny,:) - 1)/2 + pi/4) + tension2*sin(pi*(ph2(ny,:) - 1)/2 + pi/4) + tension3*sin(pi*(ph_lgm(ny,:) - 1)/2 + pi/4));
            temp1 = sum(weight.*(f0_lgm - f0),'all')*dx*dy;
            temp2 = sum(weight.*mu0.*(ph_lgm - ph3),'all')*dx*dy;
            temp3 = sum(weight(1,:).*(g_B_lgm - g_B),'all')*dx + ...
                    sum(weight(ny,:).*(g_T_lgm - g_T),'all')*dx; 
            temp4 = sum(weight(1,:).*g_p_B.*(ph_lgm(1,:) - ph3(1,:)),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T.*(ph_lgm(ny,:) - ph3(ny,:)),'all')*dx;
            temp = temp1 + temp3 - lgm*(temp2 + temp4);
        elseif strcmp(function_type,'df') == 1
            mu0_lgm_ideal = Theta*(log(ph_lgm) + log(n_c))/H_para;
            mu0_lgm_repulsion = Theta*(lambda3*ph_lgm_sum1./(H_para-ph_lgm_sum2) - log(1-ph_lgm_sum2./H_para))./H_para;
            mu0_lgm_attraction = (2*((1-binary)*sqrt(psi1*psi3)*ph1 + (1-binary)*sqrt(psi2*psi3)*ph2 + psi3*ph_lgm)./(H_para*ph_lgm_sum2) ...
                - lambda3*ph_lgm_sum3./(H_para*ph_lgm_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_lgm_sum2)./(H_para+(1+sqrt(2))*ph_lgm_sum2))/(2*sqrt(2)) ...
                + lambda3*ph_lgm_sum3./( ph_lgm_sum2.*((sqrt(2)-1)*ph_lgm_sum2-H_para).*((sqrt(2)+1)*ph_lgm_sum2+H_para) ); 
            mu0_lgm = mu0_lgm_ideal + mu0_lgm_repulsion + mu0_lgm_attraction;
            cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
            cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
            g_p_B_lgm = cf_B*tension3*cos(pi*(ph_lgm(1,:) - 1)/2 + pi/4);
            g_p_T_lgm = cf_T*tension3*cos(pi*(ph_lgm(ny,:) - 1)/2 + pi/4);
            temp1 = sum(weight.*mu0_lgm.*u2,'all')*dx*dy;
            temp2 = sum(weight.*mu0.*(ph_lgm - ph3),'all')*dx*dy;
            temp3 = sum(weight.*mu0.*u2,'all')*dx*dy;
            temp4 = sum(weight(1,:).*g_p_B_lgm.*u2(1,:),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T_lgm.*u2(ny,:),'all')*dx;
            temp5 = sum(weight(1,:).*g_p_B.*(ph_lgm(1,:) - ph3(1,:)),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T.*(ph_lgm(ny,:) - ph3(ny,:)),'all')*dx;
            temp6 = sum(weight(1,:).*g_p_B.*u2(1,:),'all')*dx + ...
                    sum(weight(ny,:).*g_p_T.*u2(ny,:),'all')*dx;
            temp = temp1 + temp4 - temp2 - temp5 - lgm*(temp3 + temp6);
        else
            error('wrong input in function type')
        end
    else
        error('wrong input in ph_flag!')
    end
end
function [u_new,v_new] = vel_solve(u,v,ph1_new,ph2_new,ph3_new)
    load(['output/','global.mat'],'nx','ny','dx','dy','dt','thickness1','thickness2','thickness3','binary_thickness','tension1','tension2','tension3', ...
        'mobility1','mobility2','mobility3','H_para','Theta','n_c','lambda1','lambda2','lambda3','psi1','psi2','psi3','Ca1','Ca2','Ca3','xi', ...
        'angle_B','angle_T','binary','Bol','Ka','Re','ph1_weight','ph2_weight','ph3_weight','beta_uw','eta','uwB','uwT');
    ph_sum1 = ph1_new + ph2_new + ph3_new;
    ph_sum2 = lambda1*ph1_new + lambda2*ph2_new + lambda3*ph3_new;
    ph_sum3 = psi1*ph1_new.*ph1_new + psi2*ph2_new.*ph2_new + psi3*ph3_new.*ph3_new ...
        + 2*(1-binary)*sqrt(psi1*psi2)*ph1_new.*ph2_new + 2*(1-binary)*sqrt(psi1*psi3)*ph1_new.*ph3_new + 2*(1-binary)*sqrt(psi2*psi3)*ph2_new.*ph3_new;
    rho = ph1_weight*ph1_new(2:ny+1,2:nx+1) + ph2_weight*ph2_new(2:ny+1,2:nx+1) + ph3_weight*ph3_new(2:ny+1,2:nx+1);
    mu10_ideal = Theta*(log(ph1_new) + log(n_c))/H_para;
    mu10_repulsion = Theta*(lambda1*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2/H_para))/H_para;
    mu10_attraction = (2*(psi1*ph1_new + (1-binary)*sqrt(psi1*psi2)*ph2_new + (1-binary)*sqrt(psi1*psi3)*ph3_new)./(H_para*ph_sum2) ...
        - lambda1*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
        + lambda1*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) ); 
    mu10 = mu10_ideal + mu10_repulsion + mu10_attraction;
    mu1 = zeros(ny+2,nx+2);
    mu1(2:ny+1,2:nx+1) = mu10(2:ny+1,2:nx+1) - thickness1^2*diff2xy(ph1_new) - binary_thickness^2*diff2xy(ph2_new) - binary_thickness^2*diff2xy(ph3_new);
    mu1 = boundary_condition(mu1,'0NM','0NM');
    mu20_ideal = Theta*(log(ph2_new) + log(n_c))/H_para;
    mu20_repulsion = Theta*(lambda2*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2/H_para))/H_para;
    mu20_attraction = (2*((1-binary)*sqrt(psi1*psi2)*ph1_new + psi2*ph2_new + (1-binary)*sqrt(psi2*psi3)*ph3_new)./(H_para*ph_sum2) ...
        - lambda2*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
        + lambda2*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) ); 
    mu20 = mu20_ideal + mu20_repulsion + mu20_attraction;
    mu2 = zeros(ny+2,nx+2);
    mu2(2:ny+1,2:nx+1) = mu20(2:ny+1,2:nx+1) - thickness2^2*diff2xy(ph2_new) - binary_thickness^2*diff2xy(ph1_new) - binary_thickness^2*diff2xy(ph3_new);
    mu2 = boundary_condition(mu2,'0NM','0NM');
    mu30_ideal = Theta*(log(ph3_new) + log(n_c))/H_para;
    mu30_repulsion = Theta*(lambda3*ph_sum1./(H_para-ph_sum2) - log(1-ph_sum2/H_para))/H_para;
    mu30_attraction = (2*((1-binary)*sqrt(psi1*psi3)*ph1_new + (1-binary)*sqrt(psi2*psi3)*ph2_new + psi3*ph3_new)./(H_para*ph_sum2) ...
        - lambda3*ph_sum3./(H_para*ph_sum2.^2)).*log((H_para+(1-sqrt(2))*ph_sum2)./(H_para+(1+sqrt(2))*ph_sum2))/(2*sqrt(2)) ...
        + lambda3*ph_sum3./( ph_sum2.*((sqrt(2)-1)*ph_sum2-H_para).*((sqrt(2)+1)*ph_sum2+H_para) ); 
    mu30 = mu30_ideal + mu30_repulsion + mu30_attraction;
    mu3 = zeros(ny+2,nx+2);
    mu3(2:ny+1,2:nx+1) = mu30(2:ny+1,2:nx+1) - thickness3^2*diff2xy(ph3_new) - binary_thickness^2*diff2xy(ph1_new) - binary_thickness^2*diff2xy(ph2_new);
    mu3 = boundary_condition(mu3,'0NM','0NM');
    cf_B = -Theta*cos(angle_B*pi/180)*pi/(12*sqrt(2)*H_para);
    cf_T = -Theta*cos(angle_T*pi/180)*pi/(12*sqrt(2)*H_para);
    L1_B = cf_B*tension1*cos(pi*(ph1_new(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness1*(ph1_new(1,2:nx+1)-ph1_new(3,2:nx+1))/(2*dy) + binary_thickness*(ph2_new(1,2:nx+1)-ph2_new(3,2:nx+1))/(2*dy) + binary_thickness*(ph3_new(1,2:nx+1)-ph3_new(3,2:nx+1))/(2*dy);
    L1_T = cf_T*tension1*cos(pi*(ph1_new(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness1*(ph1_new(ny+2,2:nx+1)-ph1_new(ny,2:nx+1))/(2*dy) + binary_thickness*(ph2_new(ny+2,2:nx+1)-ph2_new(ny,2:nx+1))/(2*dy) + binary_thickness*(ph3_new(ny+2,2:nx+1)-ph3_new(ny,2:nx+1))/(2*dy);
    L2_B = cf_B*tension2*cos(pi*(ph2_new(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness2*(ph2_new(1,2:nx+1)-ph2_new(3,2:nx+1))/(2*dy) + binary_thickness*(ph1_new(1,2:nx+1)-ph1_new(3,2:nx+1))/(2*dy) + binary_thickness*(ph3_new(1,2:nx+1)-ph3_new(3,2:nx+1))/(2*dy);
    L2_T = cf_T*tension2*cos(pi*(ph2_new(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness2*(ph2_new(ny+2,2:nx+1)-ph2_new(ny,2:nx+1))/(2*dy) + binary_thickness*(ph1_new(ny+2,2:nx+1)-ph1_new(ny,2:nx+1))/(2*dy) + binary_thickness*(ph3_new(ny+2,2:nx+1)-ph3_new(ny,2:nx+1))/(2*dy);
    L3_B = cf_B*tension3*cos(pi*(ph3_new(2,2:nx+1) - 1)/2 + pi/4) ...
        + thickness3*(ph3_new(1,2:nx+1)-ph3_new(3,2:nx+1))/(2*dy) + binary_thickness*(ph1_new(1,2:nx+1)-ph1_new(3,2:nx+1))/(2*dy) + binary_thickness*(ph2_new(1,2:nx+1)-ph2_new(3,2:nx+1))/(2*dy);
    L3_T = cf_T*tension3*cos(pi*(ph3_new(ny+1,2:nx+1) - 1)/2 + pi/4) ...
        + thickness3*(ph3_new(ny+2,2:nx+1)-ph3_new(ny,2:nx+1))/(2*dy) + binary_thickness*(ph1_new(ny+2,2:nx+1)-ph1_new(ny,2:nx+1))/(2*dy) + binary_thickness*(ph2_new(ny+2,2:nx+1)-ph2_new(ny,2:nx+1))/(2*dy);
    u_star = zeros(ny+2,nx+2);
    u_star(2:ny+1,2:nx+1) = u(2:ny+1,2:nx+1) - dt*Ka*( ph1_new(2:ny+1,2:nx+1).*diff1x(mu1) + ph2_new(2:ny+1,2:nx+1).*diff1x(mu2) + ph3_new(2:ny+1,2:nx+1).*diff1x(mu3) )./(rho*Re);
    u_star = boundary_condition(u_star,'0NM','GNBC');
    u_star(2,2:nx+1) = Bol*( L1_B.*(ph1_new(2,3:nx+2)-ph1_new(2,1:nx))/(2*dx) + L2_B.*(ph2_new(2,3:nx+2)-ph2_new(2,1:nx))/(2*dx) + L3_B.*(ph3_new(2,3:nx+2)-ph3_new(2,1:nx))/(2*dx) )/(eta*beta_uw) + uwB;
    u_star(ny+1,2:nx+1) = Bol*( L1_T.*(ph1_new(ny+1,3:nx+2)-ph1_new(ny+1,1:nx))/(2*dx) + L2_T.*(ph2_new(ny+1,3:nx+2)-ph2_new(ny+1,1:nx))/(2*dx) + L3_T.*(ph3_new(ny+1,3:nx+2)-ph3_new(ny+1,1:nx))/(2*dx) )/(eta*beta_uw) + uwT;
    v_star = zeros(ny+2,nx+2);
    v_star(2:ny+1,2:nx+1) = v(2:ny+1,2:nx+1) - dt*Ka*( ph1_new(2:ny+1,2:nx+1).*diff1y(mu1) + ph2_new(2:ny+1,2:nx+1).*diff1y(mu2) + ph3_new(2:ny+1,2:nx+1).*diff1y(mu3) )./(rho*Re);
    v_star = boundary_condition(v_star,'0NM','0DBC');
    J_flux_u = - Ca1*ph1_weight*mobility1*diff1x(mu1) - Ca2*ph2_weight*mobility2*diff1x(mu2) - Ca3*ph3_weight*mobility3*diff1x(mu3);
    J_flux_v = - Ca1*ph1_weight*mobility1*diff1y(mu1) - Ca2*ph2_weight*mobility2*diff1y(mu2) - Ca3*ph3_weight*mobility3*diff1y(mu3);
    rhs_u = Re*rho.*( u_star(2:ny+1,2:nx+1)/dt - (u_star(2:ny+1,2:nx+1).*diff1x(u) + v_star(2:ny+1,2:nx+1).*diff1y(u)) );
    rhs_u = rhs_u - (J_flux_u.*diff1x(u) + J_flux_v.*diff1y(u));
    rhs_u = rhs_u + (xi+eta/3)*(diff2x(u) + diff1xy(v));
    rhs_u(1,:) = rhs_u(1,:) + 2*eta*beta_uw*u_star(2,2:nx+1)/dy;
    rhs_u(ny,:) = rhs_u(ny,:) + 2*eta*beta_uw*u_star(ny+1,2:nx+1)/dy;
    rhs_temp = Re*rho/dt;
    A = assemble(rhs_temp,eta,beta_uw,ny,nx,'GNBC');
    [u_vec, info] = gmres(A,rhs_u(:),30,1.0e-10);
    if info ~= 0
        fprintf('The info_flag is %d\n',info);
        error('The gmres iteration can not converge!\n')
    end
    u_new = zeros(ny+2, nx+2);
    u_new(2:ny+1, 2:nx+1) = reshape(u_vec,ny,nx);
    u_new = boundary_condition(u_new,'0NM','GNBC');
    u_new(1,2:nx+1) = 2*dy*( -beta_uw*(u_new(2,2:nx+1) - u_star(2,2:nx+1)) ) + u_new(3,2:nx+1);
    u_new(ny+2,2:nx+1) = 2*dy*( -beta_uw*(u_new(ny+1,2:nx+1) - u_star(ny+1,2:nx+1)) ) + u_new(ny,2:nx+1);
    rhs_v = Re*rho.*( v_star(2:ny+1,2:nx+1)/dt - (u_star(2:ny+1,2:nx+1).*diff1x(v) + v_star(2:ny+1,2:nx+1).*diff1y(v)) );
    rhs_v = rhs_v - (J_flux_u.*diff1x(v) + J_flux_v.*diff1y(v));
    rhs_v = rhs_v + (xi+eta/3)*(diff2y(v) + diff1xy(u));
    rhs_v = rhs_v(2:ny-1,:);
    rhs_temp = rhs_temp(2:ny-1,:);
    A = assemble(rhs_temp,eta,[],ny-2,nx,'0DBC');
    [v_vec, info] = gmres(A,rhs_v(:),30,1.0e-10);
    if info ~= 0
        fprintf('The info_flag is %d\n',info);
        error('The gmres iteration can not converge!\n')
    end
    v_new = zeros(ny+2, nx+2);
    v_new(3:ny, 2:nx+1) = reshape(v_vec,ny-2,nx);
    v_new = boundary_condition(v_new,'0NM','0DBC');
    if ~isreal(u)
        error('u is imaginary')
    elseif ~isreal(v)
        error('v is imaginary')
    end
end
function global_variable()   
    nx = 100;ny = 100;x_l = 0.0;x_r = 1.0;y_b = 0.0;y_t = 1.0;
    dx = (x_r-x_l)/nx;dy = (y_t-y_b)/ny;nx = nx+1;ny = ny+1;x_inner = linspace(x_l,x_r,nx);y_inner = linspace(y_b,y_t,ny);
    x = [x_l-dx,x_inner,x_r+dx];y = [y_b-dy,y_inner,y_t+dy];[x_inner,y_inner] = meshgrid(x_inner,y_inner);[x,y] = meshgrid(x,y);
    CFL = 0.01;dt = CFL*min(dx,dy);t_final = 1;nt = ceil(t_final/dt);data_step = 10;
    thickness1 = 0.02;thickness2 = 0.05;thickness3 = 0.05;binary_thickness = 0.0001;mobility1 = 5.0e-4;mobility2 = 5.0e-4;mobility3 = 5.0e-4;
    vs1 = 5.0e0;vs2 = 5.0e0;vs3 = 5.0e0;tension1 = 0.001;tension2 = 0.001;tension3 = 0.001;
    angle = 77.6;angle_B = angle;angle_T = angle;binary = 5.0e-2;Bol = 1.6e0;Ka = Bol;eta = 1.0e0;xi = 1.0e0;Re = 1.0e1;Ca1 = 5.0e-3;Ca2 = 5.0e-3;Ca3 = 5.0e-3;
    uwT = 0.0;uwB = 0.0;beta_uw = 1/0.0038;n_c = 1;T = 323;Theta = 0.1;T_c = T/Theta;H_para = 3/8;P_c = H_para*n_c*T_c*8.314/1000;
    T_c1 = 190.56;
    P_c1 = 45.99;
    alpha1_mu0 = T_c1/T_c;
    beta1_mu0 = P_c1/P_c;
    lambda1 = 0.07780*alpha1_mu0/beta1_mu0;
    w1_mu0 = 0.011;
    m1_mu0 = 0.37464 + 1.54226*w1_mu0 - 0.26992*w1_mu0^2;
    psi1 = 0.45724*alpha1_mu0^2*(1 + m1_mu0*(1-sqrt(T/T_c1)))^2/beta1_mu0;
    ph1_weight = 16.04*0.001;
    T_c2 = 469.7;
    P_c2 = 33.70;
    alpha2_mu0 = T_c2/T_c;
    beta2_mu0 = P_c2/P_c;
    lambda2 = 0.07780*alpha2_mu0/beta2_mu0;
    w2_mu0 = 0.251;
    m2_mu0 = 0.37464 + 1.54226*w2_mu0 - 0.26992*w2_mu0^2;
    psi2 = 0.45724*alpha2_mu0^2*(1 + m2_mu0*(1-sqrt(T/T_c2)))^2/beta2_mu0;
    ph2_weight = 72.15*0.001;
    T_c3 = 617.7;
    P_c3 = 21.1;
    alpha3_mu0 = T_c3/T_c;
    beta3_mu0 = P_c3/P_c;
    lambda3 = 0.07780*alpha3_mu0/beta3_mu0;
    w3_mu0 = 0.489;
    m3_mu0 = 0.37464 + 1.54226*w3_mu0 - 0.26992*w3_mu0^2;
    psi3 = 0.45724*alpha3_mu0^2*(1 + m3_mu0*(1-sqrt(T/T_c3)))^2/beta3_mu0;
    ph3_weight = 142.28*0.001;
    weight_x = ones(1,nx);weight_x(1) = 0.5;weight_x(nx) = 0.5;weight_y = ones(ny,1);weight_y(1) = 0.5;weight_y(ny) = 0.5;weight = weight_y*weight_x;
    save(['output/','global.mat'],'nx','ny','nt','dx','dy','dt','x_inner','y_inner','x','y','t_final','data_step','weight','H_para','Theta','n_c', ...
        'thickness1','thickness2','thickness3','binary_thickness','mobility1','mobility2','mobility3', ...
        'vs1','vs2','vs3','angle_T','angle_B','tension1','tension2','tension3','ph1_weight','ph2_weight','ph3_weight', ...
        'lambda1','psi1','lambda2','psi2','lambda3','psi3','binary','Bol','Ka','eta','xi','uwB','uwT','Ca1','Ca2','Ca3','Re','beta_uw');
end
function A = assemble(a,b,c,M,N,matrix_type)
    load(['output/','global.mat'],'dx','dy','dt');
    dx2 = dx*dx;
    dy2 = dy*dy;
    if strcmp(matrix_type,'const') == 1
        A1 = spdiags([ones(M,1)*(-b/dy2) ones(M,1)*(2*b/dy2) ones(M,1)*(-b/dy2)],-1:1,M,M);
        A2 = spdiags([ones(N,1)*(-b/dx2) ones(N,1)*(2*b/dx2) ones(N,1)*(-b/dx2)],-1:1,N,N);
        A3 = speye(M)*(a);
        A1(1,2) = 2*A1(1,2);
        A1(M,M-1) = 2*A1(M,M-1);
        A2(2,1) = 2*A2(2,1);
        A2(N-1,N) = 2*A2(N-1,N);
        A = kron(speye(N),A1 + A3) + kron(A2',speye(M));
    elseif strcmp(matrix_type,'RBC') == 1
        A1 = spdiags([ones(M,1)*(-b^2/dy2) ones(M,1)*(2*b^2/dy2) ones(M,1)*(-b^2/dy2)],-1:1,M,M);
        A2 = spdiags([ones(N,1)*(-b^2/dx2) ones(N,1)*(2*b^2/dx2) ones(N,1)*(-b^2/dx2)],-1:1,N,N);
        A3 = speye(M)*(a);
        A1(1,2) = 2*A1(1,2);
        A1(1,1) = A1(1,1) + 2*b/(dt*dy*c);
        A1(M,M-1) = 2*A1(M,M-1);
        A1(M,M) = A1(M,M) + 2*b/(dt*dy*c);
        A2(2,1) = 2*A2(2,1);
        A2(N-1,N) = 2*A2(N-1,N);
        A = kron(speye(N),A1 + A3) + kron(A2',speye(M));
    elseif strcmp(matrix_type,'GNBC') == 1
        A1 = spdiags([ones(M,1)*(-b/dy2) ones(M,1)*(2*b/dy2) ones(M,1)*(-b/dy2)],-1:1,M,M);
        A2 = spdiags([ones(N,1)*(-b/dx2) ones(N,1)*(2*b/dx2) ones(N,1)*(-b/dx2)],-1:1,N,N);
        A1(1,2) = 2*A1(1,2);
        A1(1,1) = A1(1,1) + 2*b*c/dy;
        A1(M,M-1) = 2*A1(M,M-1);
        A1(M,M) = A1(M,M) + 2*b*c/dy;
        A2(2,1) = 2*A2(2,1);
        A2(N-1,N) = 2*A2(N-1,N);
        A = kron(speye(N),A1) + kron(A2',speye(M));
        a = a(:);
        A = A + spdiags(a,0,M*N,M*N);
    elseif strcmp(matrix_type,'0DBC') == 1
        A1 = spdiags([ones(M,1)*(-b/dy2) ones(M,1)*(2*b/dy2) ones(M,1)*(-b/dy2)],-1:1,M,M);
        A2 = spdiags([ones(N,1)*(-b/dx2) ones(N,1)*(2*b/dx2) ones(N,1)*(-b/dx2)],-1:1,N,N);
        A2(2,1) = 2*A2(2,1);
        A2(N-1,N) = 2*A2(N-1,N);
        A = kron(speye(N),A1) + kron(A2',speye(M));
        a = a(:);
        A = A + spdiags(a,0,M*N,M*N);
    else
        error('wrong input in matrix_type')
    end
end